"""
voting/chat_parser.py
─────────────────────
Stateless WhatsApp chat-export parser.

    parse_chat(raw_text) -> (messages, stats)

    messages : list of dicts, each:
        {"datetime": datetime, "author": str, "text": str, "is_media": bool}
    stats    : dict of counters describing what was parsed.

Mirrors the (data, stats) contract used by voting/dataset_cleaner.py so the
rest of the codebase sees a familiar shape. Nothing is mutated in place and no
database access happens here.

Supported export formats (English / en-US):
    Android : "1/1/24, 9:05 AM - Alice: message"
    iOS     : "[1/1/24, 9:05:00 AM] Alice: message"
Both 12-hour (AM/PM) and 24-hour clocks are accepted.
"""

import re
from datetime import datetime


# A line that starts a new message looks like "<date>, <time> - <rest>" (Android)
# or "[<date>, <time>] <rest>" (iOS). Anything that does not match is treated as
# a continuation of the previous message (multi-line messages).
_TIME = r"\d{1,2}:\d{2}(?::\d{2})?(?:\s*[APap][Mm])?"
_DATE = r"\d{1,2}/\d{1,2}/\d{2,4}"

_ANDROID_HEADER = re.compile(rf"^({_DATE}),\s+({_TIME})\s+-\s+(.*)$")
_IOS_HEADER = re.compile(rf"^\[({_DATE}),\s+({_TIME})\]\s+(.*)$")

# Author / system split: a real message is "Author: text". System notices
# ("Messages and calls are end-to-end encrypted...") have no "author: " prefix.
_AUTHOR_SPLIT = re.compile(r"^(?P<author>[^:\n]{1,60}):\s(?P<text>.*)$", re.DOTALL)

_MEDIA_MARKERS = ("<Media omitted>", "image omitted", "video omitted", "audio omitted")


def _normalize_spaces(value: str) -> str:
    """Replace the narrow/regular no-break spaces WhatsApp injects around AM/PM."""
    return value.replace(" ", " ").replace(" ", " ")


def _parse_datetime(date_str: str, time_str: str):
    """Try several en-US date/time layouts; return a datetime or None."""
    combined = f"{date_str.strip()} {_normalize_spaces(time_str).strip().upper()}"
    combined = re.sub(r"\s+", " ", combined)
    date_formats = ("%m/%d/%y", "%m/%d/%Y")
    time_formats = ("%I:%M %p", "%I:%M:%S %p", "%H:%M", "%H:%M:%S")
    for dfmt in date_formats:
        for tfmt in time_formats:
            try:
                return datetime.strptime(combined, f"{dfmt} {tfmt}")
            except ValueError:
                continue
    return None


def _match_header(line: str):
    """Return (date_str, time_str, rest) if the line starts a message, else None."""
    match = _ANDROID_HEADER.match(line) or _IOS_HEADER.match(line)
    if match:
        return match.group(1), match.group(2), match.group(3)
    return None


def parse_chat(raw_text: str):
    """Parse a raw WhatsApp export into structured messages plus parse stats."""
    messages = []
    stats = {
        "total_lines": 0,
        "parsed_messages": 0,
        "system_lines": 0,
        "media_messages": 0,
        "continuation_lines": 0,
        "unparsed_lines": 0,
    }

    if not raw_text:
        return messages, stats

    lines = raw_text.replace("\r\n", "\n").replace("\r", "\n").split("\n")

    for raw_line in lines:
        line = raw_line.rstrip()
        if not line.strip():
            continue
        stats["total_lines"] += 1

        header = _match_header(line)
        if header is None:
            # Continuation of the previous message (multi-line body).
            if messages:
                messages[-1]["text"] += "\n" + line
                stats["continuation_lines"] += 1
            else:
                stats["unparsed_lines"] += 1
            continue

        date_str, time_str, rest = header
        author_match = _AUTHOR_SPLIT.match(rest)
        if not author_match:
            # Header with no "author: " prefix -> system notice.
            stats["system_lines"] += 1
            continue

        dt = _parse_datetime(date_str, time_str)
        if dt is None:
            stats["unparsed_lines"] += 1
            continue

        text = author_match.group("text").strip()
        is_media = any(marker.lower() in text.lower() for marker in _MEDIA_MARKERS)
        if is_media:
            stats["media_messages"] += 1

        messages.append({
            "datetime": dt,
            "author": author_match.group("author").strip(),
            "text": text,
            "is_media": is_media,
        })
        stats["parsed_messages"] += 1

    return messages, stats
